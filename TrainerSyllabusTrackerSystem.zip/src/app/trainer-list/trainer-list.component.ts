import { Component,OnInit } from '@angular/core';
import { TrainerService } from '../trainer.service';
import { User } from '../user';

@Component({
  selector: 'app-trainer-list',
  templateUrl: './trainer-list.component.html',
  styleUrls: ['./trainer-list.component.css']
})
export class TrainerListComponent implements OnInit {

  users: User[];

  constructor(private trainerService:TrainerService){}
  ngOnInit(): void {
      this.gettrainer();
  }


  gettrainer()
  {
    this.trainerService.getTrainerList().subscribe( data => {
      this.users = data;
      console.log(this.users);

    })
  }

}
