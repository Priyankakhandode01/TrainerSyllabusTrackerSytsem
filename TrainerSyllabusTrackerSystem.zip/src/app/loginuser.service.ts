import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { User } from './user';

@Injectable({
  providedIn: 'root'
})
export class LoginuserService {

  private baseUrl = "http://localhost:8080/login";
  constructor(private httpclient:HttpClient) { }


loginUser(user:User):Observable<object>{
  console.log(user);
  
  return this.httpclient.post(`${this.baseUrl}`,user);
}


}
