import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AdminLoginComponent } from './admin-login/admin-login.component';
import { AppComponent } from './app.component';
import { AuthGuard } from './auth/auth.guard';
import { HomeComponent } from './home/home.component';
import { TrainerListComponent } from './trainer-list/trainer-list.component';
import { UserLoginComponent } from './user-login/user-login.component';
import { UserRegisterComponent } from './user-register/user-register.component';

const routes: Routes = [
  {path: 'userlogin',component:UserLoginComponent},
  {path: 'user-register',component: UserRegisterComponent},
  // {path: 'home', component: HomeComponent},
  {path: 'home/:id',component:HomeComponent},
  {path: 'trainer-list',component:TrainerListComponent},
  {path: 'admin',component:AdminLoginComponent},

  {path: '', redirectTo: 'userlogin', pathMatch:'full'}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
