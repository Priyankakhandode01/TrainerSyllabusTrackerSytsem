import { NgFor } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Route, Router } from '@angular/router';
import { Course } from '../course';
import { CourseService } from '../course.service';
import { TrainerService } from '../trainer.service';
import { User } from '../user';
import { UserLoginComponent } from '../user-login/user-login.component';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {

  id: number;
  user: User;
  mcourse: Course;
  topiclist: Course[]
  per:number;
  m: UserLoginComponent;
  constructor(private courseService: CourseService,
    private trainerService: TrainerService,
    private route: ActivatedRoute,
    private router: Router) { }

  ngOnInit(): void {
    this.id = this.route.snapshot.params['id'];
    this.getallcourse();
    this.getlist();
    this.getTrainer();





  }



  getTrainer() {
    this.trainerService.getTrainerById(this.id).subscribe(data => {
      console.log(this.user = data);
    });
  }

  getlist() {
    console.log("Sub : ", typeof this.id);
    this.mcourse = new Course();
    this.user = new User();
    this.courseService.getcourselist(this.id).subscribe(data => {
      console.log("Mcourse : ", this.mcourse = data);

      let count = 0;
      if (this.mcourse.c1 == true) count = count +5;
      if (this.mcourse.c2 == true) count = count +5;
      if (this.mcourse.c3 == true) count = count +5;
      if (this.mcourse.c4 == true) count = count +5;
      if (this.mcourse.c5 == true) count = count +5;
      if (this.mcourse.c6 == true) count = count +5;
      if (this.mcourse.c7 == true) count = count +5;
      if (this.mcourse.c8 == true) count = count +5;
      if (this.mcourse.c9 == true) count = count +5;
      if (this.mcourse.c10 == true) count = count +5;
      if (this.mcourse.c11 == true) count = count +5;
      if (this.mcourse.c12 == true) count = count +5;
      if (this.mcourse.c13 == true) count = count +5;
      if (this.mcourse.c14 == true) count = count +5;
      if (this.mcourse.c15 == true) count = count +5;
      if (this.mcourse.c16 == true) count = count +5;
      if (this.mcourse.c17 == true) count = count +5;
      if (this.mcourse.c18 == true) count = count +5;
      if (this.mcourse.c19 == true) count = count +5;
      if (this.mcourse.c20 == true) count = count +5;


      console.log(this.per= count);
      
      


    });
  }

  getallcourse() {
    console.log("Sub : ", typeof this.id);
    this.courseService.getallcourselist().subscribe(data => {
      console.log("Topic List >>> :", this.topiclist = data);

    });
  }



  onchange() {
    console.log("Data Change", this.mcourse);

  }


  onSubmit() {
    this.courseService.updatecourse(this.id, this.mcourse).subscribe(data => {
      alert("Data Save Successfully");
      

      // this.router.navigate(['/userlogin']);
      console.log("Data Save Successfully >> ",this.mcourse);

      
    });

    console.log("Percentage >>>> ",this.user.per = this.per);
    
    // this.trainerService.updatetrainer(this.id,this.user).subscribe(data => {
    //   console.log("Updated data >>>>>>>>> ",this.user);
    window.location.reload();
    // });
  }




}
