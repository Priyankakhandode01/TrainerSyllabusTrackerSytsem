export class User {
    id:string;
    name:string;
    email:string;
    password:number;
    repassword:number;
    gender:string;
    selectcourseName:string;
    per:number;

}
