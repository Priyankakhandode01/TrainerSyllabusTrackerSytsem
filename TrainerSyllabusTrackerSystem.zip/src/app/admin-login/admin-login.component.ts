import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-admin-login',
  templateUrl: './admin-login.component.html',
  styleUrls: ['./admin-login.component.css']
})
export class AdminLoginComponent implements OnInit {


  constructor(private route: Router) { }

  ngOnInit(): void {

  }



  userLogin() {
    // let x = document.getElementById("id").value;
    let name: string = (<HTMLInputElement>document.getElementById("id")).value;
    let pass: string = (<HTMLInputElement>document.getElementById("password")).value;

    if (name == "admin" && pass == "admin") {
      this.gotologin();
    } else {
      alert("wrong credentials")
    }
  }


  gotologin() {
    this.route.navigate(['trainer-list']);
  }




}



