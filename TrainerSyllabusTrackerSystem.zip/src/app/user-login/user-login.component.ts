import { Component, OnInit } from '@angular/core';
import { FormGroup,FormControl,Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { LoginuserService } from '../loginuser.service';
import { User } from '../user';

@Component({
  selector: 'app-user-login',
  templateUrl: './user-login.component.html',
  styleUrls: ['./user-login.component.css']
})
export class UserLoginComponent implements OnInit {

  id:number;
  user:User = new User();
  loginFrom :FormGroup;

  constructor(private loginuserService:LoginuserService,
    private route:Router,
    private mroute:ActivatedRoute){}

  ngOnInit(): void {
   
  }

  userLogin(){
    this.id = parseInt(this.user.id);
    this.loginuserService.loginUser(this.user).subscribe(data => {
      this.gotohome();
    },error=>alert("Enter the Correct Credetional"));
    
  }

  gotohome()
  {
    // this.route.navigate(['/home']);
    this.route.navigate(['/home',this.id]);
  }

  gotoregister()
  {
    this.route.navigate(['/user-register']);    
  }

}
