import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { User } from './user';

@Injectable({
  providedIn: 'root'
})
export class TrainerService {

  private baseUrl = "http://localhost:8080/addTrainer"
  private url = "http://localhost:8080/trainerdetail"
  private trainerlisturl = "http://localhost:8080/trainers"
  private trainerupdate = "http://localhost:8080/trainerupdateper"

  constructor(private httpClient: HttpClient) {
   }

   addtrainer(trainer:User):Observable<Object>{
    return this.httpClient.post(`${this.baseUrl}`,trainer);
   }

   getTrainerById(id:number):Observable<User>{
      return this.httpClient.get<User>(`${this.url}/${id}`);
   }

   getTrainerList():Observable<User[]>{
    return this.httpClient.get<User[]>(`${this.trainerlisturl}`)
   }

   updatetrainer(id:number,user:User):Observable<object>{
    return this.httpClient.put(`${this.trainerupdate}/${id}`,user);
   }

  

}
