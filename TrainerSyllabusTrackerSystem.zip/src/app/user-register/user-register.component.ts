import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { isEmpty } from 'rxjs';
import { Course } from '../course';
import { CourseService } from '../course.service';
import { TrainerService } from '../trainer.service';
import { User } from '../user';

@Component({
  selector: 'app-user-register',
  templateUrl: './user-register.component.html',
  styleUrls: ['./user-register.component.css']
})
export class UserRegisterComponent implements OnInit {

  user: User = new User();
  course: Course = new Course();

  constructor(private route: Router,
    private trainerService: TrainerService,
    private courseService: CourseService) { }

  ngOnInit(): void {

  }

  saveTrainer() {
    this.trainerService.addtrainer(this.user).subscribe(data => {
      console.log(data);

    },
      error => console.log(error));
  }

  userRegistraction() {
    console.log(this.user);
    // this.checkvalidation();

    if (this.user.email != null && this.user.repassword != null && this.user.password != null &&
      this.user.gender != null && this.user.name != null && this.user.selectcourseName != null) {
      console.log("Valid");

      this.setCourseTopics();// set topics
      console.log(this.course.courseName);
      this.saveTrainer();
      alert("Register Sucessfully");
      this.gotologin();


    } else {
      console.log("InValid");
    }



  }

  checkvalidation() {



  }

  gotologin() {
    this.route.navigate(['/userlogin']);
  }
  setCourseTopics() {

    this.course.courseName = this.user.selectcourseName;
    if (this.course.courseName == "Full Stack Java") {
      this.bindJava();
    }
    if (this.course.courseName == "Software Testing") {
      this.bindTesting();
    }
    if (this.course.courseName == "Machine Learning") {
      this.bindMachine();
    }
    if (this.course.courseName == "Cloud Computing") {
      this.bindCloud();
    }




    this.courseService.addcourse(this.course).subscribe(data => {
      console.log(data);

    },
      error => console.log(error));
  }



  bindJava() {
    this.course.p1 = "Introduction to java";
    this.course.p2 = "OOPS concepts";
    this.course.p3 = "Basic Java constructs like loops and data types";
    this.course.p4 = "String handling";
    this.course.p5 = "Collection framework";
    this.course.p6 = "Multithreading";
    this.course.p7 = "Exception handling";
    this.course.p8 = "Generics";
    this.course.p9 = "Synchronisation";
    this.course.p10 = "Serialisation & De-serialisation";
    this.course.p11 = "Concurrent collection";
    this.course.p12 = "JDBC (Java Database Connectivity)";
    this.course.p13 = "Servlet";
    this.course.p14 = "JSP";
    this.course.p15 = "Spring (MVC, Core, JDBC, ORM, AOP)";
    this.course.p16 = "Hibernate ORM framework";
    this.course.p17 = "Struts";
    this.course.p18 = "JSF";
    this.course.p19 = "Web Services (SOAP & REST)";
    this.course.p20 = "Project";
  }

  bindTesting() {

    this.course.p1 = "Unit Testing";
    this.course.p2 = "Integration Testing";
    this.course.p3 = "System Testing";
    this.course.p4 = "Functional Testing";
    this.course.p5 = "Acceptance Testing";
    this.course.p6 = "Smoke Testing";
    this.course.p7 = "Regression Testing";
    this.course.p8 = "Performance Testing";
    this.course.p9 = "Security Testing";
    this.course.p10 = "User Acceptance Testing";
    this.course.p11 = "Agile and DevOps";
    this.course.p12 = "Test Automation";
    this.course.p13 = "API and Services Test Automation";
    this.course.p14 = "Artificial Intelligence for Testing";
    this.course.p15 = "Mobile Test Automation";
    this.course.p16 = "Test Environments and Data";
    this.course.p17 = "Integration of Tools and Activities";
    this.course.p18 = "Design Review & Software Testing";
    this.course.p19 = "Execution of System Tests";
    this.course.p20 = "Project";

  }

  bindCloud() {

    this.course.p1 = "Unit Testing";
    this.course.p2 = "Integration Testing";
    this.course.p3 = "System Testing";
    this.course.p4 = "Functional Testing";
    this.course.p5 = "Acceptance Testing";
    this.course.p6 = "Smoke Testing";
    this.course.p7 = "Regression Testing";
    this.course.p8 = "Performance Testing";
    this.course.p9 = "Security Testing";
    this.course.p10 = "User Acceptance Testing";
    this.course.p11 = "Agile and DevOps";
    this.course.p12 = "Test Automation";
    this.course.p13 = "API and Services Test Automation";
    this.course.p14 = "Artificial Intelligence for Testing";
    this.course.p15 = "Mobile Test Automation";
    this.course.p16 = "Test Environments and Data";
    this.course.p17 = "Integration of Tools and Activities";
    this.course.p18 = "Design Review & Software Testing";
    this.course.p19 = "Execution of System Tests";
    this.course.p20 = "Project";

  }


  bindMachine() {
    this.course.p1 = "Unit Testing";
    this.course.p2 = "Integration Testing";
    this.course.p3 = "System Testing";
    this.course.p4 = "Functional Testing";
    this.course.p5 = "Acceptance Testing";
    this.course.p6 = "Smoke Testing";
    this.course.p7 = "Regression Testing";
    this.course.p8 = "Performance Testing";
    this.course.p9 = "Security Testing";
    this.course.p10 = "User Acceptance Testing";
    this.course.p11 = "Agile and DevOps";
    this.course.p12 = "Test Automation";
    this.course.p13 = "API and Services Test Automation";
    this.course.p14 = "Artificial Intelligence for Testing";
    this.course.p15 = "Mobile Test Automation";
    this.course.p16 = "Test Environments and Data";
    this.course.p17 = "Integration of Tools and Activities";
    this.course.p18 = "Design Review & Software Testing";
    this.course.p19 = "Execution of System Tests";
    this.course.p20 = "Project";
  }

}
