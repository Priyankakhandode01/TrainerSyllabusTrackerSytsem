import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Course } from './course';
import { User } from './user';

@Injectable({
  providedIn: 'root'
})
export class CourseService {

  private addCourseUrl="http://localhost:8080/addcourse";
  private displayCourseUrl="http://localhost:8080/getsinglecourse";
  private displayAllCourseUrl = "http://localhost:8080/displaycourse";
  private updateurl = "http://localhost:8080/updatecoursebox"
  
  constructor(private httpcliet: HttpClient) { }

  getcourselist(id:number):Observable<Course>{
    return this.httpcliet.get<Course>(`${this.displayCourseUrl}/${id}`);
  }

  getallcourselist():Observable<Course[]>
  {
    return this.httpcliet.get<Course[]>(`${this.displayAllCourseUrl}`);
  }

  addcourse(course:Course):Observable<Object>{
    return this.httpcliet.post(`${this.addCourseUrl}`,course);
   }

   updatecourse(id:number,course:Course):Observable<object>{
    return this.httpcliet.put(`${this.updateurl}/${id}`,course);
   }

 


}
