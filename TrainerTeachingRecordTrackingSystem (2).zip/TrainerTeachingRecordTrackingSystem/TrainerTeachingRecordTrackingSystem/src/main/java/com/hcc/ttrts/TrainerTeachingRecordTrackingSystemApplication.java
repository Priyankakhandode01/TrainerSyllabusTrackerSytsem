package com.hcc.ttrts;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TrainerTeachingRecordTrackingSystemApplication {

	public static void main(String[] args) {
		SpringApplication.run(TrainerTeachingRecordTrackingSystemApplication.class, args);
	}

}
