package com.hcc.ttrts.Controllers;

import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;


import com.hcc.ttrts.Models.Course;
import com.hcc.ttrts.Repositories.CourseRepository;

@RestController
public class CourseController {
	
	@Autowired
	CourseRepository courseRepository;
	
	
	@CrossOrigin
	@GetMapping("/displaycourse")
	public List<Course> coursedis(){
		return courseRepository.findAll();
	}
	

	@PostMapping("/addcourse")
	public Course addcourse(@RequestBody Course c){
		return courseRepository.save(c);
	}
	
	@PutMapping("/updatecourse")
	public Course updatecourse(@RequestBody Course c) {
		return courseRepository.save(c);
	}
	
	@DeleteMapping("/deletecourse/{id}")
	public String deletecourse(@PathVariable("id") int id) {
		courseRepository.deleteById(id);
		return "Deleted...";
	}
	
	@CrossOrigin
	@GetMapping("/getsinglecourse/{id}")
	public Course getsinglecourse(@PathVariable("id") int id) {
		return courseRepository.findById(id).get();
	}
	
	@CrossOrigin
	@PutMapping("/updatecoursebox/{id}")
	public Course updateStudent(@PathVariable int id, @RequestBody Course student){
		Course st = courseRepository.findById(id).get();
		st.setC1(student.isC1());
		st.setC2(student.isC2());
		st.setC3(student.isC3());
		st.setC4(student.isC4());
		st.setC5(student.isC5());
		st.setC6(student.isC6());
		st.setC7(student.isC7());
		st.setC8(student.isC8());
		st.setC9(student.isC9());
		st.setC10(student.isC10());
		st.setC11(student.isC11());
		st.setC12(student.isC12());
		st.setC13(student.isC13());
		st.setC14(student.isC14());
		st.setC15(student.isC15());
		st.setC16(student.isC16());
		st.setC17(student.isC17());
		st.setC18(student.isC18());
		st.setC19(student.isC19());
		st.setC20(student.isC20());
		
		return courseRepository.save(st);
	}
}
